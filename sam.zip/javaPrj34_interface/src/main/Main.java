package main;

public class Main {

	public static void main(String[] args) {

		System.out.println("====== Interface ======");
		
		Animal x = new Dog();
	}

	/*
	 * 추상메서드에만 있음
	 * 인터페이스로 다중상속 가능
	 */
}
