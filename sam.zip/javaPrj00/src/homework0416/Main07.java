package homework0416;

import java.util.Scanner;

public class Main07 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int x = sc.nextInt();
		int y = sc.nextInt();
		
		while(x<=y) {
			System.out.print(x++);
		}
	}

}
