package homework0416;

import java.util.Scanner;

public class Main03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int n = sc.nextInt();
		int m = sc.nextInt();
		
		int x = n+m;
		
		System.out.println(n + "+" + m + "=" + x);
	}

}
