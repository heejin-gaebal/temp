package homework0416;

import java.util.Scanner;

public class Main06 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int x = sc.nextInt();
		int n = sc.nextInt();
		
		if(x % n == 0) {
			System.out.println("ㅇㅇ");
		}else {
			System.out.println("ㄴㄴ");			
		}
	}

}
