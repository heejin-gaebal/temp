package temp;

public class Main {

	public static void main(String[] args) {

		System.out.println("구구단 만들기");
		
		for(int i=2; i <= 9; i++) {
			for(int j=1; j<=9; j++) {
				int z = i*j;
				System.out.println(i +" * "+ j + " = " + z);
			}
		}
	}

}
