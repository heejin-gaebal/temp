package programmers;

import java.util.Scanner;

public class Solution2 {
    public int[][] solution(int n) {
        int[][] answer = new int[n][n];
       int value = 1;
       
       int top = 0;
       int left = 0;
       int right = n-1;
       int bottom = n-1;
       
       //value 값이 n*n 가 될때까지 ㄱㄱ
       while(value <= n*n) {
          // → : 상단행 : x 고정 , y 증가
           for(int i = left ; i <= right; ++i) {
              answer[top][i] = value++;
           }
           top++;
           // ↓ : 우측열 : x 증가 , y 고정
           for(int i = top ; i <= bottom; ++i) {
              answer[i][right] = value++;
           }
           right--;
           // ← : 하단행 : x 고정 , y 감소
           for(int i = right ; i >= left; --i) {
              answer[bottom][i] = value++;
           }
           bottom--;
           // ↑ : 좌측열 : x 감소 , y 고정
           for(int i = bottom ; i >= top; --i) {
              answer[i][left] = value++;
           }
           left++;
       }
       
       
       
        return answer;
    }
}