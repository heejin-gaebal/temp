package programmers;

import java.util.Scanner;

public class Solution {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a = sc.next();
        
        //하나의 열을 쪼개기 한글자씩 배열
        
        //
        
        
        System.out.println(a);
    }
}