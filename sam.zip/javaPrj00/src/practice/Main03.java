package practice;

import java.util.Scanner;

public class Main03 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		
		// x 가 30~40 사이의 값이면 good 아니면 bad
		// 비교+논리 연산자 응용
		
		if(30 < x && x < 40) {
			System.out.println("good");
		}else {
			System.out.println("bad");
		}
	}

}
