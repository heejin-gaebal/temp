package practice;

import java.util.Scanner;

public class Main02 {

	public static void main(String[] args) {
		System.out.println("=====if=====");
		
		Scanner sc = new Scanner(System.in);
		int score = sc.nextInt();
		
		if(score > 4) {
			System.out.println("A");			
		}
		if(score > 3) {
			System.out.println("B");
		}
		if(score > 2) {
			System.out.println("C");			
		}
		// 각각의 3개의 if 문
	}

}
