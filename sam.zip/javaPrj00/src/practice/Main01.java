package practice;

import java.util.Scanner;

public class Main01 {

	public static void main(String[] args) {
		// if 중첩문
		System.out.println("=====condition=====");
		
		Scanner sc = new Scanner(System.in);
	    
		// sc.nextInt(); 정수 입력데이터
		// sc.nextLine(); 문자열 입력데이터
		//double x = sc.nextDouble(); //실수 입력데이터
		
		System.out.println("나이를 입력하세요.");
		
		int x = sc.nextInt();
		
		if(x > 0) {
			if(x >= 20) {
				System.out.println("요금 1,000원");
			}else {
				System.out.println("요금 700원");
			}
		}else {
			System.out.println("잘못 입력하셨습니다.");
		}
	}
}
