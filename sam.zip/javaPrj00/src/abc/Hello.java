package abc;

public class Hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("안녕하세요 \n저는 \"홍길동\" 입니다"); // 화면(콘솔)에 출력하는 출력문 
		
		/*
		 * \n : enter 줄바꿈
		 * \" : "" 쌍따옴표 표현
		 * cotrl + / : 주석처리
		 * ctrl + alt : 줄 복제
		 * ctrl + d : 한줄 삭제
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * */
		
	}

}
