package test;

import java.util.Scanner;

public class CodeUp1070 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	    		
		int x = sc.nextInt();
		
		if(x==12 || x==1 || x==2) {
			System.out.println("winter");
		}
		if(x==3 || x==4 || x==5) {
			System.out.println("spring");
		}
		if(x==6 || x==7 || x==8) {
			System.out.println("summer");
		}
		if(x==9 || x==10 || x==11) {
			System.out.println("fall");
		}
		
//		switch(x) {
//			case 1 : System.out.println("winter"); 
//				break;
//			case 2 : System.out.println("winter");
//			break;
//			case 3 : System.out.println("spring");
//			break;
//			case 4 : System.out.println("spring");
//			break;
//			case 5 : System.out.println("spring");
//			break;
//			case 6 : System.out.println("summer");
//			break;
//			case 7 : System.out.println("summer");
//			break;
//			case 8 : System.out.println("summer");
//			break;
//			case 9 : System.out.println("fall");
//			break;
//			case 10 : System.out.println("fall");
//			break;
//			case 11 : System.out.println("fall");
//			break;
//			case 12 : System.out.println("winter");
//			break;
//		}
	}

}
