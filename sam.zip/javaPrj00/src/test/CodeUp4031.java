package test;

import java.util.Scanner;

public class CodeUp4031 {

	public static void main(String[] args) {
		//스캐너 만들기
		Scanner sc = new Scanner(System.in);
	
		//7개의 자연수 100보다 작음
		//홀수 큰수 찾기
		//짝수 큰수 찾기
		//큰 수끼리 합하기
		
		int oddMax = 0;
		int evenMax = 0;
		
		//7번 반복
		for(int i=0; i<7; i++) {
			//정수 입력받음
			int num = sc.nextInt();
			
			//홀수
			if(num % 2 == 1) {
				if(oddMax < num) {
					oddMax = num;
				}
			}else if(num % 2 == 0) {//짝수
				if(evenMax < num) {
					evenMax = num;
				}
			}
		}
		System.out.println(oddMax + evenMax);
		
	}
}
