package test;

public class CodeUp {

	public static void main(String[] args) {
		System.out.println("히히456415646");
	}

}
