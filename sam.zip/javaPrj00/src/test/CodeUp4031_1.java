package test;

import java.util.Scanner;

public class CodeUp4031_1 {

	public static void main(String[] args) {
		//스캐너 만들기
		Scanner sc = new Scanner(System.in);
	
		//7개의 자연수 100보다 작음
		//홀짝판단 우선		
		//홀수 큰수 찾기
		//짝수 큰수 찾기
		//큰 수끼리 합하기
		
		int oddMax = 0; //최대값 셋팅
		int evenMax = 0; //최대값 셋팅
		
		for(int i=0; i<7; i++) {
			//제일큰 숫자 먼저 출력
			int num = sc.nextInt();
			
			//홀수 검사
			if(num % 2 == 1) {
				//기존 최대값보다 num이 더 크면 대체
				if(oddMax < num) {
					oddMax = num;
				}
			}else {//짝수 검사
				if(evenMax < num) {
					evenMax = num;
				}
			}
		}
		
		System.out.println(oddMax + evenMax);
	}
}
