//반복문 연습
package test;

import java.util.Scanner;

public class CodeUp1256 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		for(int cnt = 0; cnt < n; cnt++) {
			System.out.print("*");
		}
		
	}

}
