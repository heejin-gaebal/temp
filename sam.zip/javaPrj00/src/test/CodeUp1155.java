package test;

import java.util.Scanner;

public class CodeUp1155 {

	public static void main(String[] args) {
		//정수 입력받기
		//7의 배수 판별
		Scanner sc = new Scanner(System.in);
	    
		int x = sc.nextInt();
		
		if(x % 7 == 0) {			
			System.out.println("multiple");
		}else {			
			System.out.println("not multiple");
		}
	}

}
