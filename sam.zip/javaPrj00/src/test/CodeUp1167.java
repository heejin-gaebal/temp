package test;

import java.util.Scanner;

public class CodeUp1167 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	    
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		
		if(a>=b && a<=c || a>=c && a<=b) {
			//a 가 b 보다 크고 c 보다 작거나 or a 가 c 보다 크고 b 보다 작거나
			System.out.println(a);
		}
		else if(b>=a && b<=c || b>=c && b<=a) {
			//b 가 a 보다 크고 c 보다 작거나 or b 가 c 보다 크고 a 보다 작거나
			System.out.println(b);
		}
		else if(c>=a && c<=b || c>=b && c<=a) {
			//c 가 a 보다 크고 b 보다 작거나 or c 가 b 보다 크고 a 보다 작거나
			System.out.println(c);
		}
	}

}
