package test;

import java.util.Scanner;

public class CodeUp1160 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	    
		int x = sc.nextInt();
		
		if(x % 2 != 0) {
			System.out.println("oh my god");
		}else if(x % 2 == 0) {
			System.out.println("enjoy");
		}
	}

}
