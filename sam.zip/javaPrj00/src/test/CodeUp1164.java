package test;

import java.util.Scanner;

public class CodeUp1164 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	    
		int x = sc.nextInt();
		int y = sc.nextInt();
		int z = sc.nextInt();
		
		if(x <= 170 || y<= 170 || z <= 170) {
			System.out.println("CRASH");
		}else if(x > 170 || y > 170 || z > 170){
			System.out.println("PASS");
		}
	}
}
