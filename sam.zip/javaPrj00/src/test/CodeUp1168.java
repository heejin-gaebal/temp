package test;

import java.util.Scanner;

public class CodeUp1168 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	    
		//정수 2개 입력(주민번호 앞자리, 뒷자리)
		//나이 출력 (2012년 기준)
		
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		int year = 0;
		
		if(num2 == 1 || num2 == 2) {
			year = num1 / 10000 + 1900; 			
		}else if(num2 == 3 || num2 == 4) {
			year = num1 / 10000 + 2000;
		}
		
		//앞자리 2자리만 필요하므로 나누기 10000
		//1900년대생은 + 1900
		
		int age = 2012 - year + 1;
		// if 문 안에 year 변수있으므로 if 문에서만 사용가능 - 지역변수
		// year 변수가 두개 있지만, 서로 지역이 다르므로 사용가능
		// year 변수를 새로 만들어줘야함
		
		/*
		 * { => scope
		 * }
		 * scope 안에서 쓰인 변수는 scope 안에서만 사용가능
		 * 
		 * 외부 scope 에서 선언된 변수는 
		 * 내부 scope 에서 선언할 필요가 없다.
		 * 
		 */
		
		System.out.println(age);
		
	}

}
