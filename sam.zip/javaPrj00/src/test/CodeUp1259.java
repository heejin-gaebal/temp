//반복문 연습
package test;

import java.util.Scanner;

public class CodeUp1259 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int sum = 0;
		int num;
		
		for(num = 1; num <= n; num++) {
			if(num % 2 == 0)
			sum += num;
		}
		System.out.println(sum);		
	}

}
