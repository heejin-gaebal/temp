//반복문 연습
package test;

import java.util.Scanner;

public class CodeUp1268 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int result = 0;
		
		for(int i=1; i<=n; i++) {
			int m = sc.nextInt();
			if(m % 2 != 0) {
				result += m;
			}
		}
		System.out.println(result);
	}

}
