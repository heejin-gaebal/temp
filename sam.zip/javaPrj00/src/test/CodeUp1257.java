//반복문 연습
package test;

import java.util.Scanner;

public class CodeUp1257 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int a = sc.nextInt();
		int b = sc.nextInt();
		
		int x;
		for(x = a;  x <= b; x++) {
			if(x % 2 == 0) {
				continue;
			}
			System.out.println(x);
		}
		
	}

}
