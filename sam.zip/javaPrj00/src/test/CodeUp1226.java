package test;

import java.util.Scanner;

public class CodeUp1226 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	    
		//당첨번호
		int lotto1 = sc.nextInt();
		int lotto2 = sc.nextInt();
		int lotto3 = sc.nextInt();
		int lotto4 = sc.nextInt();
		int lotto5 = sc.nextInt();
		int lotto6 = sc.nextInt();
		//보너스번호
		int bonus = sc.nextInt();

		//가진 숫자
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		int num3 = sc.nextInt();
		int num4 = sc.nextInt();
		int num5 = sc.nextInt();
		int num6 = sc.nextInt();
		
		int cnt = 0;
		int bonusCnt = 0;
		
		if(num1==lotto1 || num1==lotto2 || num1==lotto3 || num1==lotto4 || num1==lotto5 || num1==lotto6) {
			//num과 lotto값을 비교해서 같으면 카운트 증가
			cnt = cnt + 1;
		}
		if(num2==lotto1 || num2==lotto2 || num2==lotto3 || num2==lotto4 || num2==lotto5 || num2==lotto6) {
			cnt = cnt + 1;
		}
		if(num3==lotto1 || num3==lotto2 || num3==lotto3 || num3==lotto4 || num3==lotto5 || num3==lotto6) {
			cnt = cnt + 1;
		}
		if(num4==lotto1 || num4==lotto2 || num4==lotto3 || num4==lotto4 || num4==lotto5 || num4==lotto6) {
			cnt = cnt + 1;
		}
		if(num5==lotto1 || num5==lotto2 || num5==lotto3 || num5==lotto4 || num5==lotto5 || num5==lotto6) {
			cnt = cnt + 1;
		}
		if(num6==lotto1 || num6==lotto2 || num6==lotto3 || num6==lotto4 || num6==lotto5 || num6==lotto6) {
			cnt = cnt + 1;
		}
		
		if(num1 == bonus || num2 == bonus || num3 == bonus || num4 == bonus || num5 == bonus || num6 == bonus) {
			bonusCnt=1; 			
		}

		if(cnt==6) {	//1등
			System.out.println(1); 			
		}else if(cnt==5 && bonusCnt==1) {	//2등
			System.out.println(2);
		}else if(cnt==5) {	//3등
			System.out.println(3);			
		}else if(cnt==4) {	//4등
			System.out.println(4);			
		}else if(cnt==3) {	//5등
			System.out.println(5);			
		}else {	//꽝
			System.out.println(0);			
		}
	}
}
