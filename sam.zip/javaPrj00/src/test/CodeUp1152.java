package test;

import java.util.Scanner;

public class CodeUp1152 {

	public static void main(String[] args) {

		/*
		 * 정수 입력받고, small 이나 big 출력
		 * 10보다 작으면 small, 크면 big
		 */
		
		Scanner sc = new Scanner(System.in);
	     
		int x = sc.nextInt();
		
		if(x < 10) {
			System.out.println("small");			
		}else {
			System.out.println("big");
		}
	}

}
