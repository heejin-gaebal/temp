package test;

import java.util.Scanner;

public class CodeUp1409 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
				
		//우선 10개가 들어갈 배열 만들기
		int[] arr = new int[10];
		
		for(int i=0; i<10; i++) {
			//숫자 10개 입력받아서 배열에 저장
			arr[i] = sc.nextInt();			
		}
		
		//두번째 값 입력
		int n = sc.nextInt();
		
		//해당값을 찾기위해 출력
		System.out.println(arr[n-1]);
		
	}

}
