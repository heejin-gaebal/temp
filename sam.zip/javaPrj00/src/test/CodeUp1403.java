package test;

import java.util.Scanner;

public class CodeUp1403 {

	public static void main(String[] args) {
		
		// 배열 2번 출력하기
		//스캐너 만들기
		Scanner sc = new Scanner(System.in);
		
		//정수 1개받기 (숫자 n 개 들어옴)
		int n = sc.nextInt();
		
		//사이즈가 n 인 배열 만들기
		int[] arr = new int[n];
		
		//n 번만큼 정수 입력받기
		for(int i=0; i<n; i++) {//0부터 시작하므로 n 전까지 반복
			int input = sc.nextInt();		
			arr[i] = input;
		}
		
		//입력받은 정수들을 출력(2번)
		for(int i=0; i<n; i++) {
			System.out.println(arr[i]);
		}
		for(int i=0; i<n; i++) {
			System.out.println(arr[i]);
		}
	}

}
