package test;

import java.util.Scanner;

public class CodeUp1067 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	    
		int x = sc.nextInt();
		
		if(x < 0) {
			System.out.println("minus");
		}else if(x > 0){
			System.out.println("plus");
		};
		
		if(x % 2 != 0){
			System.out.println("odd");
		}else if(x % 2 == 0) {
			System.out.println("even");
		};
		
	}

}
