//반복문 연습
package test;

import java.util.Scanner;

public class CodeUp1267 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int sum = 0;

		for(int i = 1; i <= n; i++) {
			int m = sc.nextInt();
			if(m % 5 == 0) {
				sum += m;
			}
		}
		System.out.println(sum);
	}

}
