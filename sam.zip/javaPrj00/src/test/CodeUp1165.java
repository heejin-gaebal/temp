package test;

import java.util.Scanner;

public class CodeUp1165 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	    
		int x = sc.nextInt();
		
		if(x % 400 == 0) {
			System.out.println("Leap");
		}else if(x % 4 == 0 && x % 100 != 0) {
			System.out.println("Leap");
		}else {
			System.out.println("Normal");
		}
	}
}
