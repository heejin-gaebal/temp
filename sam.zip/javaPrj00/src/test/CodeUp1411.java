package test;

import java.util.Scanner;

public class CodeUp1411 {

	public static void main(String[] args) {
		//스캐너 만들기
		Scanner sc = new Scanner(System.in);
		
		/*
		 * 빠진 카드 찾기
		 * 
		 * 원래 몇장인지 알기 
		 * 한장 빠진 지금 들고있는거 알려줌
		 * 갖고있는것을 보고 순회하면서 제외
		 * 
		 * 
		 * 빠진거 찾아서 말하기
		 * 
		 */
		
		//원래 몇장인지 알기 : 정수 n 입력
		int n = sc.nextInt();
		
		//갖고있는 것 저장하므로 n 사이즈로 새로 배열만들기
		//원래의 숫자를 기억해야하므로 변수 n 개 먼저 만들어야함
		//숫자카드가 1부터 시작하므로 1칸을 더 만들고, 0번은 비워둔다
		// 5장이면 0~4가아니고 1~5가 되게!
		//모든 칸 0으로 초기화
		int[] memo = new int[n+1];
		
		//n-1번 반복해야함
		for(int i=0; i<n-1; i++) {
			int num = sc.nextInt();
			//지금 갖고있는 것 알려줌 : 정수 n-1개 입력
			//새로 만든 배열에 입력받고 임의로 1로 채워주고 마지막 배열칸에 0인것을 찾기
			memo[num] = 1;
		}
		
		//빠진거 찾아서 말하기
		//변수를 하나 만들어서 1~n 까지 들어가게
		for(int i=1; i<=n; i++) {
			//해당조건이 true 면(배열의 값이 0이면) i 번 카드가 빠진 것.
			if(memo[i]==0) {
				System.out.println(i);
				break;
			}
		}
	}
}















