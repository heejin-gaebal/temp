package test;

import java.util.Scanner;

public class CodeUp4026 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		
		int num[] = new int[5];
		
		int maxNum01 = 0;
		int maxNum02 = 0;
		
		for(int i=0; i<5; i++) {
			num[i] = sc.nextInt();
			
			if(num[i] < num[5]) {
				
			}
			
			System.out.println(num[i]);
		}
	}
}
