package test;

import java.util.Scanner;

public class CodeUp1151 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		//입력받는 곳 | 콘솔창에 입력

		int x = sc.nextInt();
		// x 에 입력값 대입
		
		if(x < 10) {
			System.out.println("small");			
		}
	} 
}
/*
 * 저장 실행 후 
 * Console 창에 입력커서 생성
 * 값 입력 후 Enter
 * */