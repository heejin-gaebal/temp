//반복문 연습
package test;

import java.util.Scanner;

public class CodeUp1266 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int m;
		int sum = 0;

		for(m = 1; m <= n; m++) {
			sum += sc.nextInt();
		}
		System.out.println(sum);
	}

}
