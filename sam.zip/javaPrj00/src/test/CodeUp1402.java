package test;

import java.util.Scanner;

public class CodeUp1402 {

	public static void main(String[] args) {
		//정수 n 하나 입력
		
		//n 개 정수 입력
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		//n 개의 정수를 받을 수 있는 배열 만들기
		int[] arr = new int[n];
		
		for(int i=0; i<n; i++) {
			arr[i] = sc.nextInt();
		}
		
		for(int i=n-1; i>=0; i--) {
			System.out.println(arr[i]);			
		}
	}

}
