//반복문 연습
package test;

import java.util.Scanner;

public class CodeUp1260 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int a = sc.nextInt();
		int b = sc.nextInt();

		int x;
		int sum = 0;
		
		for(x = a; x <= b; x++) {
			if(x % 3 == 0) {
				sum += x;
			}
		}
		System.out.println(sum);		
	}

}
