//반복문 연습
package test;

import java.util.Scanner;

public class CodeUp1252 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int x = sc.nextInt();
	    for(int y = 1; y <= x; y++) {
	    	System.out.println(y);
	    }
		
	}

}
