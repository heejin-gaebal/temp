package test;

import java.util.Scanner;

public class CodeUp1214 {

	public static void main(String[] args) {
		
		//월 입력받고, 말일 출력하기
		Scanner sc = new Scanner(System.in);
	    int month = sc.nextInt();
	    
	    // Switch 문	    
	    /*
	     * switch(비교할 값) {
	     * 
	     * 경우 1
	     * 경우 2
	     * 경우 3
	     * .
	     * .
	     * }
	     * 
	     * break; 
	     * 가까운 반복문이나 switch 문을 깨트림
	     * 마지막 case 에는 break 안써도 됨 어차피 switch문 종료
	     * 
	     */
	    
	    switch(month) {
	    case 1: 
	    case 3: 
	    case 5: 
	    case 7: 
	    case 8: 
	    case 10: 
	    case 12: System.out.println("31"); break;
	    case 4: 
	    case 6: 
	    case 9: 
	    case 11: System.out.println("30"); break;
	    default: System.out.println("28"); 
	    }
	}

}

