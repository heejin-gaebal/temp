//반복문 연습
package test;

import java.util.Scanner;

public class CodeUp1253 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int a = sc.nextInt();
		int b = sc.nextInt();
		int x = a;
		
	    for(x = a; x <= b; x++) {
	    	if(x >= b || x <= b) {
	    		System.out.printf(x + " "); // " " 쌍따옴표 안 띄어쓰기로 공백출력
	    	}
	    }
		
	}

}
