package test;

import java.util.Scanner;

public class CodeUp1460 {

	public static void main(String[] args) {
		//스캐너 만들기
		Scanner sc = new Scanner(System.in);

		//3*3 2차원배열 만들기
		int n = sc.nextInt(); //배열값을 바꿔주면서 n*n 배열을 만들수 있음
		int[][] x = new int[n][n];
		int y = 1;
		
		//각 칸에 1~9 순서대로 채우기
		for(int i=0; i<n; i++) {	//0~n 까지
			for(int j=0; j<n; j++) {
				x[i][j] = y++; //값 증가를 위해 y 변수 추가해줌
			}
		}
		
		//모든 값 출력
		for(int a=0; a<n; a++) {	//0~n 까지
			for(int b=0; b<n; b++) {
				System.out.print(x[a][b]);				
				System.out.print(" ");				
			}
			System.out.println("");
		}
		
	}
}















