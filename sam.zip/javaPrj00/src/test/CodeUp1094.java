package test;

import java.util.Scanner;

public class CodeUp1094 {

	public static void main(String[] args) {
		//n 명에 대한 출석 부른 내용 기억했다가 거꾸로 말하기

		//스캐너 만들기
		Scanner sc = new Scanner(System.in);
					 	//객체의     주소값
		
		//n 명에 대한 변수 n 을 만들기
		//정수타입 변수 n 을 선언, 스캐너로 입력값 n 에 할당
		int n = sc.nextInt();
		
		//배열을 먼저 만들고 입력값 [배열]에 담기
		int[] arr = new int[n];

		//출석내용 == 정수 입력받기 * n 번 반복 
		for(int i=0; i<n; i++) {
			//입력받은 것을 배열에 담기
			arr[i] = sc.nextInt();
		}

		//거꾸로 말하기 == 배열에 담긴 것 거꾸로 출력 "print"
		//반복출력하기 
		//n의 배열에는 값이 없으므로 n-1로 조건을 잡아서 n~0까지 출력하게 함. 
		for(int x=n-1; x>=0; x--) {
			System.out.println(arr[x]);
		}
	}
}
