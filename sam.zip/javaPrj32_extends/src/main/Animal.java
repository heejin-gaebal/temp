package main;

public abstract class Animal { //추상 클래스
	
	int a;

	String name;
	int age;
	
	public String toString() {
		return "Animal [name=" + name + ", age=" + age + "]";
	}
	
	public abstract void cry(); //추상 메서드 - 오버라이딩
	/*
	 * 오버로딩 : 이름은 같은데 파라미터만 다름 [메서드와 생성자에 적용가능]
	 * public void m01(){}
	 * public void m01(int x){}		각각 파라미터가 다름
	 * public void m01(float x){}
	 * 
	 * 오버라이드 :
	 * 	부모에게 추상메서드가 있다면 자식이 재정의 덮어쓰기하는 것
	 *
	 * 상속 : 부모클래스의 내용 자식한테 전달
	 *
	 * 인터페이스 : 추상메서드에만 있음
	 * - 오버라이딩 강제화
	 * - 다형성 적용
		 좀 더 범용적인 타입을 사용하는게 유연한 코딩을 하게 됨
		 다형성 적용하면 정적바인딩 문제 생김
		 문제해결하려고 메서드 선언
		 메서드 바디는 굳이 필요없이 추상메서드로 작성
	 *
	 * 추상클래스 : 객체 생성불가능
	 * 추상메서드 : 메서드 바디가 없음
	 * 추상메서드 있으면 추상클래스 
	 * 추상메서드 없어도 추상클래스가 될 수 있다.
	 * 
	 * instanceof Person : 객체타입을 검사
	 * 
	 */
}
