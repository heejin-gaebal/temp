package book;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BookController {
	private Scanner sc = new Scanner(System.in);
	private List<BookVo> bookList = new ArrayList<BookVo>();
	
	public void menu() {
		while(true) {
			printmenu();
			int num = scanNumber();
			if(num==0) {System.out.println("프로그램 종료");break;}
			callFunction(num);
		}
	}
	
	private void printmenu() {
		System.out.println("======= 메뉴 =======");
		System.out.println("0. 프로그램 종료");
		System.out.println("1. 도서 등록");
		System.out.println("2. 도서 목록 조회");
	}
	
	private int scanNumber() {
		System.out.println("메뉴 번호 입력 : ");
		int num  = Integer.parseInt(sc.nextLine());
		return num;
	}
	
	private void callFunction(int num) {
		switch(num) {
		case 1 : insertBook();break;
		case 2 : selectBookList(); break;
		default : System.out.println("잘못 누르셨습니다.");
		}
	}
	
	public void insertBook() {
		System.out.println("도서 등록");
		System.out.println("도서 제목 : ");
		String title = sc.nextLine();
		System.out.println("도서 가격 : ");
		int price = Integer.parseInt(sc.nextLine());
		System.out.println("도서등록 완료!");
		
		BookVo vo = new BookVo(title, price);
		bookList.add(vo);
	}
	public void selectBookList() {
		for(int i=0; i<bookList.size(); i++) {
			System.out.println(bookList.get(i));
		}
	}
}
