package book;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BookController {
	//BookVo만 들어오게 리스트 추가
	private Scanner sc = new Scanner(System.in);
//	private List<BookVo> bookList = new ArrayList<BookVo>();
	//메서드 작성//

	//메뉴
	public void menu() throws Exception {
		while(true) {
			printmenu();
			int num = scanNumber();
			if(num==0) {System.out.println("프로그램이 종료됩니다.");break;}
			callFunction(num);
		}
	}
	
	private void printmenu() {
		System.out.println("------ MENU ------");
		System.out.println("0. 프로그램 종료");
		System.out.println("1. 도서 등록");
		System.out.println("2. 도서 목록 조회");
	}
	
	private int scanNumber() {
		//번호 입력
		System.out.println("메뉴 번호 입력");
		int num = Integer.parseInt(sc.nextLine());
		return num;
	}

	private void callFunction(int num) throws Exception{
		//메서드 호출
		switch(num) {
		case 1 : insertBook(); break;
		case 2 : selectBookList(); break;
		default : System.out.println("잘못 누르셨습니다.");
		}
	}

	//도서 등록
	public void insertBook() throws Exception {
		//data
		System.out.println("도서를 등록해주세요");
		System.out.print("도서 제목 : ");
		String title = sc.nextLine(); 
		System.out.print("도서 가격 : ");
		int price = Integer.parseInt(sc.nextLine()); 
		System.out.println("도서등록 완료!");
		
		//data -> 객체
		BookVo vo = new BookVo(title, price);
		
		//1. bookList에 객체담기 | vo라는 변수에 담은 객체를 리스트에 추가
		//bookList.add(vo); [리스트 사용]

		//2. bookList에 객체담기 | data.txt라는 파일에 기록 : 통로만들고 내보내기(Stream)
		/*파일 객체 = 파일경로   \\, \n.. : escape 문자 */ 
		File f = new File("D:\\dev\\java_repo\\data.txt"); 
		FileWriter fw = new FileWriter(f, true); //예외 던지기
		//통로끝
		
//		fw.write(vo.toString()); //write 맞는 타입이 없으므로 데이터를 담은 클래스객체.toString()으로 명시
		fw.write(vo.getTitle() + " / " + vo.getPrice()); //toString 편집
		fw.write("\n"); //줄바꿈 처리
		fw.flush();
	}
	
	//도서 목록 조회
	public void selectBookList() throws Exception {
		//2. bookList의 객체 전부 받아오기 | data.txt라는 파일 내용 출력 : 통로만들고 내보내기(Stream)
		//받을 객체 다시 변수 만들기
		File f = new File("D:\\dev\\java_repo\\data.txt");
		FileReader fr = new FileReader(f);
		BufferedReader br = new BufferedReader(fr);
		//통로끝
		while(true) {
			String str = br.readLine(); //읽어들인 문자열을 str에 저장
			if(str == null) {break;}
			//반복출력 -> null 이면 반복그만
			System.out.println(str); //str출력	
		}
		
		//1. bookList의 객체를 get 으로 받아옴
//		for(int i=0; i<bookList.size(); i++) {
//			System.out.println(bookList.get(i));
//			
//		}
	}
}
