package main;

public class Main {

	public static void main(String[] args) {
		
		//배열에 있는 모든 값 출력하기
		int[] arr = new int[10];
		arr[0] = 10;
		arr[1] = 20;
		arr[2] = 30;
		arr[3] = 40;
		arr[4] = 50;
		arr[5] = 60;
		arr[6] = 70;
		arr[7] = 80;
		arr[8] = 90;
		arr[9] = 100;
		
		//1. 출력
		for(int i=0; i<arr.length; i++) {
			System.out.println(arr[i]);
		}
		
		//2. 출력
		for(int x : arr) { //arr 배열의 요소를 꺼내서 x에 담는 것을 반복
			System.out.println(x);
		}
	}

}
